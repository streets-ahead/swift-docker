public enum Atom {
  case primative(_: Type)
  case symbol(_: String)
  case list(_: [Atom])
  case define
  case iff
  case lambda
  
  public init(_ tok: String) {
    if tok == "def" {
      self = .define
    } else if tok == "if" {
      self = .iff
    } else if tok == "lambda" {
      self = .lambda
    } else if let type = Type(tok) {
      self = .primative(type)
    } else {
      self = .symbol(tok)
    }
  }
}

extension Atom: Equatable {}

public func ==(lhs: Atom, rhs: Atom) -> Bool {
  switch (lhs, rhs) {
  case (let .primative(type1), let .primative(type2)):
    return type1 == type2
  
  case (let .symbol(str1), let .symbol(str2)):
    return str1 == str2
  
  case (let .list(list1), let .list(list2)):
    return list1 == list2
  
  case (.define, .define):
    return true
  
  case (.iff, .iff):
    return true
  
  case (.lambda, .lambda):
    return false
  
  default:
    return false
  }
}