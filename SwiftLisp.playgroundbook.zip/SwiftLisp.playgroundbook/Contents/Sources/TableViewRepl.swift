import UIKit

let AnyCell = "AnyCell"

extension UIFont {
  static let replFont = UIFont.monospacedDigitSystemFont(ofSize: 18, weight: UIFont.Weight.medium)
}

extension UIColor {
  static let inputColor = UIColor(red:0.47, green:0.61, blue:0.75, alpha:1.00)
  static let outputColor = UIColor(red:0.45, green:0.97, blue:0.49, alpha:1.00)
  static let terminalBackground = UIColor(red:0.18, green:0.24, blue:0.31, alpha:1.00)
}

enum CellType {
  case result(value: String)
  case input(value: String)
  case cursor
}

class PromptCell: UITableViewCell {
  private lazy var shellPrompt: UILabel = {
    let prompt = UILabel()
    prompt.text = "  >"
    prompt.font = .replFont
    prompt.textColor = .inputColor
    prompt.backgroundColor = .clear
    prompt.translatesAutoresizingMaskIntoConstraints = false
    return prompt
  }()
  
  lazy var textField: UITextField = {
    let textField = UITextField()
    textField.text = ""
    textField.font = .replFont
    textField.keyboardType = .numbersAndPunctuation
    textField.backgroundColor = .clear
    textField.translatesAutoresizingMaskIntoConstraints = false
    return textField
  }()
  
  var isResult: Bool = false {
    didSet {
      if isResult {
        textField.textColor = .outputColor
        textField.isEnabled = false
        shellPrompt.isHidden = true
      } else {
        textField.textColor = .inputColor
        textField.isEnabled = false
        shellPrompt.isHidden = false
      }
    }
  }
  
  override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
    super.init(style: .default, reuseIdentifier: reuseIdentifier)
    contentView.addSubview(shellPrompt)
    contentView.addSubview(textField)
    backgroundColor = .terminalBackground
    
    shellPrompt.leftAnchor.constraint(equalTo: contentView.leftAnchor).isActive = true
    shellPrompt.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
    shellPrompt.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
    shellPrompt.widthAnchor.constraint(equalToConstant: 30.0).isActive = true
    
    textField.leftAnchor.constraint(equalTo: shellPrompt.rightAnchor).isActive = true
    textField.topAnchor.constraint(equalTo: contentView.topAnchor).isActive = true
    textField.bottomAnchor.constraint(equalTo: contentView.bottomAnchor).isActive = true
    textField.rightAnchor.constraint(equalTo: contentView.rightAnchor).isActive = true
  }
  
  required init?(coder aDecoder: NSCoder) {
    fatalError("init(coder:) has not been implemented")
  }
}

public class TableViewRepl: UITableViewController, UITextFieldDelegate {
  var stack = [CellType.cursor]
  var currentPrompt: UITextField? = nil
  lazy var tapGesture = UITapGestureRecognizer(target: self, action: #selector(TableViewRepl.handleTap))

  public override func viewDidLoad() {
    super.viewDidLoad()
    tableView.register(PromptCell.self, forCellReuseIdentifier: AnyCell)
    tableView.allowsSelection = false
    tableView.separatorColor = .clear
    tableView.backgroundColor = .terminalBackground
    tableView.clipsToBounds = true
    tableView.translatesAutoresizingMaskIntoConstraints = false
    
    tapGesture.cancelsTouchesInView = true
    tableView.addGestureRecognizer(tapGesture)
  }
  
  public func textFieldShouldReturn(_ textField: UITextField) -> Bool {
    evalCurrent()
    return true
  }
  
  @objc func handleTap() {
    currentPrompt?.becomeFirstResponder()
  }
  
  public func evalCurrent() {
    let text = currentPrompt?.text ?? "()"
    stack.insert(.input(value: text), at: stack.count - 1)
    stack.insert(.result(value: eval(string: text)), at: stack.count - 1)
    
    // TODO: Probably don't need to reload all, could maybe add insert animation
    tableView.reloadData()
    currentPrompt?.resignFirstResponder()
    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1, execute: {
      self.currentPrompt?.becomeFirstResponder()
    })
  }
  
  public override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return stack.count
  }
  
  public override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
    return 35
  }
  
  // Auto insert close parens, probably not the best way but this works
  public func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
    if string == "(" {
      let beginning = textField.beginningOfDocument
      let start = textField.position(from: beginning, offset: range.location)
      let cursorOffset = textField.offset(from: beginning, to: start!) + string.count
      
      textField.text = (textField.text as NSString?)?.replacingCharacters(in: range, with: "()")
      
      let newCursorPosition = textField.position(from: textField.beginningOfDocument, offset: cursorOffset)
      let newSelectedRange = textField.textRange(from: newCursorPosition!, to: newCursorPosition!)
      textField.selectedTextRange = newSelectedRange
      
      return false
    }
    return true
  }
  
  public override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: AnyCell) as! PromptCell
    let value = stack[indexPath.row]
    switch  value {
    case let .input(val):
      cell.textField.text = val
      cell.textField.delegate = nil
      cell.isResult = false
    case let .result(val):
      cell.textField.text = val
      cell.textField.delegate = nil
      cell.isResult = true
    case .cursor:
      cell.isResult = false
      cell.textField.text = ""
      cell.textField.delegate = self
      cell.textField.isEnabled = true
      currentPrompt = cell.textField
    }
    return cell
  }
}
