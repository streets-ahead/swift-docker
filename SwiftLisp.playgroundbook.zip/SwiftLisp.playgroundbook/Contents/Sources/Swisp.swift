import UIKit

public enum ParseError: Error {
  case syntaxError(String)
  case evalError(String)
}

/*:
 Tokenize a Swisp expression string, an expression should be either an atom like `34` or `false`, or a list `(+ 3 2)`
 
 @return List of string tokens
 */
func tokenize(_ expr: String) -> [String] {
  var str = expr.replacingOccurrences(of: "(", with: " ( ")
  str = str.replacingOccurrences(of: ")", with: " ) ")
  return str
    .trimmingCharacters(in: .whitespacesAndNewlines)
    .components(separatedBy: .whitespacesAndNewlines)
    .filter {$0.count > 0}
}

public func head<A>(_ list: [A]) -> (A?, [A]) {
  return (list.first, Array(list.dropFirst()))
}

func parse(list: [String]) throws -> (Atom, [String]) {
  var tokens = list
  var result: [Atom] = []
  while tokens.first != ")" {
    let (next, rest) = try parse(tokens)
    result.append(next)
    tokens = rest
    
    if(tokens.count == 0) {
      throw ParseError.syntaxError("Expected Atom")
    }
  }
  return (.list(result), Array(tokens.dropFirst()))
}

func parse(_ tokens: [String]) throws -> (Atom, [String]) {
  let (first, rest) = head(tokens)
  
  if first == nil {
    throw ParseError.syntaxError("Expected Atom")
  }
  
  switch first! {
  case "(":
    return try parse(list: rest)
    
  case ")":
    throw ParseError.syntaxError("Unexpected ) found.")
    
  default:
    return (Atom(first!), rest)
  }
}

func intOp(_ op: @escaping ([Int]) -> Type) -> ([Type]) throws -> Type {
  return {list in
    let input = try list.map {arg -> Int in
      guard case let .int(int) = arg else {
        throw ParseError.syntaxError("Expected Int, got \(arg)")
      }
      return int
    }
    return op(input)
  }
}

func extractArgs(from list: Atom) throws -> [String] {
  guard case let .list(argList) = list else { throw ParseError.evalError("Expected argument list") }
  var result = [String]()
  for case let .symbol(str) in argList {
    result.append(str)
  }
  return result
}

public class Environment {
  var parent: Environment?
  var env: [String: Type]
  
  public init(_ initial: [String: Type] = [String: Type](), parent: Environment? = nil) {
    self.parent = parent
    env = initial
  }
  
  public subscript(symbol: String) -> Type? {
    get {
      if let value = env[symbol] {
        return value
      }
      return parent?[symbol]
    }
    set {
      env[symbol] = newValue
    }
  }
}

let rootEnv = Environment([
  "+": Type.lambda(intOp { .int($0.reduce(0, +)) }),
  "-": Type.lambda(intOp { .int($0.dropFirst().reduce($0[0], -)) }),
  "*": Type.lambda(intOp { .int($0.reduce(1, *)) }),
  "/": Type.lambda(intOp { .int($0.dropFirst().reduce($0[0], /)) }),
  "<": Type.lambda(intOp { .bool($0[0] < $0[1]) }),
  ">": Type.lambda(intOp { .bool($0[0] > $0[1]) }),
  "=": Type.lambda(intOp { .bool($0[0] == $0[1]) }),
  ])

func eval(list: [Atom], env: Environment) throws -> Type {
  guard list.count > 0 else { return .list([]) }
  
  switch list[0] {
  case .define:
    guard list.count == 3,
      case let .symbol(symbol) = list[1]
      else { throw ParseError.evalError("Define takes two arguments, a symbol and value") }
    let value = try eval(list[2], env: env)
    env[symbol] = value
    return value
    
  case .iff:
    guard list.count > 2 else { throw ParseError.evalError("If takes at least 2, a condition and a statement") }
    let condition = try eval(list[1], env: env)
    if condition.truthy {
      return try eval(list[2], env: env)
    }
    return list.count == 4 ? try eval(list[3], env: env) : .null
    
  case .symbol(_):
    let (fun, args) = head(list)
    guard case let .lambda(fn) = try eval(fun!, env: env) else {
      throw ParseError.evalError("Expected function, found \(String(describing: fun))")
    }
    return try fn(args.map { try eval($0, env: env) })
    
  case let .list(list):
    return try eval(list: list, env: env)
    
  case .lambda:
    let argNames = try extractArgs(from: list[1])
    return Type.lambda {args in
      guard argNames.count == args.count else {
        throw ParseError.evalError("Expected \(argNames.count) arguments, got \(args.count)")
      }
      var dict = [String: Type]()
      for (i, name) in argNames.enumerated() {
        dict[name] = args[i]
      }
      let fnEnv = Environment(dict, parent: env)
      return try eval(list[2], env: fnEnv)
    }
    
  default:
    throw ParseError.evalError("Expected operation.")
  }
}

func eval(_ expr: Atom, env: Environment) throws -> Type {
  switch expr {
  case .symbol(let sym):
    return env[sym] ?? .null
    
  case .list(let list):
    return try eval(list: list, env: env)
    
  case let .primative(value):
    return value
    
  default:
    throw ParseError.syntaxError("Expected symbol list or value.")
  }
}

func eval(string: String) -> String {
  do {
    return try "\(eval(parse(tokenize(string)).0, env: rootEnv))"
  } catch let error as ParseError {
    return String(describing: error)
  } catch  {
    print("Error:", error)
  }
  return ""
}
