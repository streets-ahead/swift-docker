
// Represents runtime types
public enum Type {
  case bool(_: Bool)
  case int(_: Int)
  case null
  case lambda(_: ([Type]) throws -> Type)
  case list(_: [Type])
  
  public init?(_ tok: String) {
    if let int = Int(tok) {
      self = .int(int)
    } else if let bool = Bool(tok) {
      self = .bool(bool)
    } else if tok == "null" {
      self = .null
    } else {
      return nil
    }
  }
}

extension Type: Equatable {}

public func ==(lhs: Type, rhs: Type) -> Bool {
  switch (lhs, rhs) {
  case (let .bool(bool1), let .bool(bool2)):
    return bool1 == bool2
  
  case (let .int(i1), let .int(i2)):
    return i1 == i2
  
  case (.null, .null):
    return true
  
  case (.lambda, .lambda):
  // TODO: implement lamda eq
    return false
  
  case (let .list(l1), let .list(l2)):
    return l1 == l2
  
  default:
    return false
  }
}

extension Type {
  public var truthy: Bool {
    switch self {
    case let .bool(b):
      return b
      
    case let .int(i):
      return i != 0
      
    case let .list(l):
      return l.count > 0
      
    default:
      return false
    }
  }
}

extension Type: CustomStringConvertible {
  public var description: String {
    switch self {
    case let .bool(b):
      return String(describing: b)
      
    case let .int(i):
      return String(describing: i)
      
    case .lambda:
      return "{Func}"
      
    case .list:
      return "{List}"
      
    case .null:
      return "{null}"
    }
  }
}