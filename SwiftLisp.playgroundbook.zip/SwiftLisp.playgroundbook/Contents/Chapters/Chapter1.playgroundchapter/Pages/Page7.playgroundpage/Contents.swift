//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
# Eval

Its now time to actually evaluate and execute our Swisp input.  Below is our outer eval function.  This function is relatively simple.  Out input is a symbol we try to look up the value in our environment.  If the input is a primative value we simply return the value.  The only other case we need to handle here is list because the other members of our Atom enum can only occurn inside a list.  Since evaluating a list is a little more complicated we can break that out into a separate function.

*/

func eval(_ expr: Atom, env: Environment) throws -> Type {
  switch expr {
  case .symbol(let sym):
    return env[sym] ?? .null
    
  case let .primative(value):
    return value

  case .list(let list):
    return try eval(list: list, env: env)
    
  default:
    throw ParseError.syntaxError("Expected symbol, list or value.")
  }
}

/*:
## Eval List

The final step is to evaluate our list.  We'll need to handle each of the cases below.  I've already added some basic argument checking, your challenge will be to complete the evaluation code for each case below.

*/

func eval(list: [Atom], env: Environment) throws -> Type {
  guard list.count > 0 else { return .list([]) }
  
  switch list[0] {
  
  /*:
  Define is used to define a variable.  The input will look like `(def x 43)`.  You'll need to evaluate the third argument, and update the local environment by assigning that value to env[symbol].  Finally return the value.
  */
  case .define:
    guard list.count == 3,
      case let .symbol(symbol) = list[1]
      else { throw ParseError.evalError("Define takes two arguments, a symbol and value, ex: (def x (+ 3 3))") }
    //#-editable-code Write Code Here
    //#-end-editable-code
    return value
    
  /*:
  In the case of conditional `if` expressions you'll need to check the truthy property of the evaluated condition, then if true evaluate and return the list[2].  If its false evaluate and return list[3], unless there is no list[3], in that case return null.
  */
  case .iff:
    guard list.count > 2 
      else { throw ParseError.evalError("if takes at least 2 arguments, a condition and a statement, ex: (if (< x 3) 10 (+ 2 2))") }
    let condition = try eval(list[1], env: env)
    //#-editable-code Write Code Here
    //#-end-editable-code
  
  /*:
  If the current Atom is a symbol, it should reference a function in the environment.  First you'll need to lookup the function by evaluating list[0], next you'll need to evaluate each argument, then evaluate the function passing the computed arguments.
  */
  case .symbol(_):
    let (fun, args) = head(list)
    guard case let .lambda(fn) = try eval(fun!, env: env) else {
      throw ParseError.evalError("Expected function, found \(String(describing: fun))")
    }
    //#-editable-code Write Code Here
    //#-end-editable-code
    
  case let .list(list):
    return try eval(list: list, env: env)
    
  /*:
  The lambda case is slightly more complicated, in this case you'll need to create a new Swift closure to represent the new function. Then create a new environment so that the function has a local scope.  Lastly you'll need to prefill that environment with the parameters.  You can call the `extractArgs` function provided below in order to extract the argument names.
  */
  case .lambda:
    let argNames = try extractArgs(from: list[1])
    return Type.lambda {args in
      guard argNames.count == args.count else {
        throw ParseError.evalError("Expected \(argNames.count) arguments, got \(args.count)")
      }
      var dict = [String: Type]()
      for (i, name) in argNames.enumerated() {
        dict[name] = args[i]
      }
      //#-editable-code Create a new environment and use it to eval the list[2]
      //#-end-editable-code
    }
    
  default:
    throw ParseError.evalError("Expected function or operation.")
  }
}

//TODO: Add assertions

/*:
This helper method will extract the argument name values from an argument list.
 */
func extractArgs(from list: Atom) throws -> [String] {
  guard case let .list(argList) = list else { throw ParseError.evalError("Expected argument list") }
  var result = [String]()
  for case let .symbol(str) in argList {
    result.append(str)
  }
  return result
}

