//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
## Tokenizer
 
The first step in writing our Swisp interpreter is tokenizing.  Tokenization is the process of breaking up the input
into a stream of tokens to feed to our parser.  For example, if the input program is `(+ 1 2)`, then the tokens would be five strings: `["(", "+",
"1", "2" and ")"]`.

Complete the function below which takes a string representing a program, and returns and array of strings representing the tokens.

 */

func tokenize(_ expr: String) -> [String] {
  //#-editable-code Write Code Here
  //#-end-editable-code 
}

assert(tokenize("()") == ["(", ")"])
assert(tokenize("(+ 4 5)") == ["(", "+", "4", "5", ")"])
assert(tokenize("(- 10 (* 2 2))") == ["(", "-", "10", "(", "*", "2", "2", ")", ")"])
