//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
# Truthy or Falsy

One more thing we need to decide about our language is how to determine if a value should be true or false.  Swift is very strict and will only allow us to use explicit true or false boolean values in conditionals.  Its common in Lisps to be more general, for example in most Lisps null will evaluate to false, as will zero and empty lists.  Below I've included an extension to our Type enum to determine whether a value is true or false.

**Challenge**: Implement +, \* and / in our environment dictionary below. 

 */

extension Type {
  public var truthy: Bool {
    //#-editable-code Write Code Here
    switch self {
    case let .bool(b):
      return b
      
    case let .int(i):
      return i != 0
      
    case let .list(l):
      return l.count > 0
      
    case .lambda:
      return true

    default:
      return false
    }
    //#-end-editable-code
  }
}

/*:
  Try tweaking the test cases below and update the logic above to decide what Truthy should mean in your language.
*/
//#-editable-code Write Code Here
assert(Type.int(0).truthy == false)
assert(Type.int(2).truthy == true)
assert(Type.bool(false).truthy == false)
assert(Type.list([]).truthy == false)
assert(Type.list([Type.int(1), Type.int(2)]).truthy == true)
assert(Type.null.truthy == false)
//#-end-editable-code
