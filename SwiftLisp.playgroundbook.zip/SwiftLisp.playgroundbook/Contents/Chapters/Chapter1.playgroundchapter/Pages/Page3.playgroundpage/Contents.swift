//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
## Parsing
 
The next step is to parse our tokens.  Parsing will convert our flat stream of tokens into an AST or abstract syntax tree. An AST is how our program is represented to the computer, it is a simple tree data structure that will be easy for our interpreter to traverse when running our code.  
 
As part of the parsing step we will also convert each token into its correct type, for example if we see a token string representing a number then we'll convert it from a string to its number value.  Our AST will not contain the parenthesis characters as those are only used to denote the structure of our program, and once we've used them in parsing they are no longer needed.  We will define two enum types to be used during parsing, Atom and Type.  

Atom will represent the meaningful tokens in our program. The current version of Swisp will include:

 * pimative - Represents the primative types like int or boolean.
 * symbol - A symbol representing a variable.
 * list - A list of other Atoms.
 * define - Represents the `def`` keyword
 * iff - Represents the `if` keyword
 * lambda - Represents the lambda keyword.

 */

enum Atom {
  case primative(_: Type)
  case symbol(_: String)
  case list(_: [Atom])
  case define
  case iff
  case lambda
  
  init(_ tok: String) {
    if tok == "def" {
      self = .define
    } else if tok == "if" {
      self = .iff
    } else if tok == "lambda" {
      self = .lambda
    } else if let type = Type(tok) {
      self = .primative(type)
    } else {
      self = .symbol(tok)
    }
  }
}

/*:
Type will represent the runtime types used while executing Swisp programs.
*/

enum Type {
  case bool(_: Bool)
  case int(_: Int)
  case null
  case lambda(_: ([Type]) throws -> Type)
  case list(_: [Type])
  
  init?(_ tok: String) {
    if let int = Int(tok) {
      self = .int(int)
    } else if let bool = Bool(tok) {
      self = .bool(bool)
    } else if tok == "null" {
      self = .null
    } else {
      return nil
    }
  }
}

