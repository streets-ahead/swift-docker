//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
## Environment

In order for Swisp to be useful we need to provide a base set of functions that our programs can invoke, we'll call this the execution environment. Our environment will be a `Dictionary<String: Atom>`. To start off we will only include the four basic math operations, +, -, \*, /. 

**Challenge**: Implement +, \*, /, and > in our environment dictionary below.  Feel free to keep going as well, you could add % (modulo), ==, <=, as many as you want.

 */
enum ParseError: Error {
  case syntaxError(String)
  case evalError(String)
}

/*:
In order to keep our math functions simple we want the signature to be `([Int]) -> Int`, but since our data is stored as Atoms we'll use the below `intOp` helper method, which will unwrap our list of arguments and return the result wrapped in an Atom
*/
func intOp(_ op: @escaping ([Int]) -> Type) -> ([Type]) throws -> Type {
  return {list in
    let input = try list.map {arg -> Int in
      guard case let .int(int) = arg else {
        throw ParseError.syntaxError("Expected Int, got \(arg)")
      }
      return int
    }
    return op(input)
  }
}

let env: [String: Type]  = [
  "-": Type.lambda(intOp { .int($0.dropFirst().reduce($0[0], -)) }),
  "<": Type.lambda(intOp { .bool($0[0] < $0[1]) }),
  //#-editable-code Write Code Here
  //#-end-editable-code
]

// TODO: add assertions

/*:
### Environment Class

We need to create an environment class as a wrapper for our environment dictionary because ultimately we need a heiarchy of environments, since each function will create its own scope.  The simple class below will give us this flexability.

**Challenge**: Implement the subscript method below for our Environment class.  Remember it will need to check its local scope first, if its not found there it should continue searching up the parent chain until it either finds the value or the parent is nil.
*/

class Environment {
  var parent: Environment?
  var env: [String: Type]
  
  init(_ initial: [String: Type] = [String: Type](), parent: Environment? = nil) {
    self.parent = parent
    env = initial
  }
  
  subscript(symbol: String) -> Type? {
    get {
      //#-editable-code Write Code Here
      //#-end-editable-code
    }
    set {
      //#-editable-code Write Code Here
      //#-end-editable-code
    }
    
  }
}

// TODO: add assertions
