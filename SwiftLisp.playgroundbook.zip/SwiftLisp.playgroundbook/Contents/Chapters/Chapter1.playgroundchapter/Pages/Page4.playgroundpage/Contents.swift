//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:
# Parsing Continued

Now that we have our Atom enum, we can complete our parse function.  The input to the parse function will be the result of our tokenize function.  The output will be an AST, or in our case a list of Atoms, which can then contain nested lists forming a tree.  
 
### Example 0: 

```swift
parse(["(", "+", "1", "2", ")"]) == [
   Atom.symbol("+"), 
   Atom.int(1), 
   Atom.int(2)
]
```

### Example 1: 

```swift
parse(["(", "+", "1", "(", "-", "3", "2", ")", ")"]) == [
  Atom.symbol("+"), 
  Atom.int(1),
  Atom.list([
   Atom.symbol("-"), 
   Atom.int(3), 
   Atom.int(2)
  ])
] // Notice the nested list, the nested lists are what forms our tree.
```

**Challenge**: Given the mutally recursive funtions below, complete the `parse(list:)` function.  This function is called when we are inside a list, it will need to iterate through and parse each token until it finds the ending ")" character, or runs out of tokens.  If it runs out of tokens you should throw an error.  The functions are called mutually recursive becuase the `parse` function will call the `parse(list:)` function, and vice versa.
 
 */
 
func head<A>(_ list: [A]) -> (A?, [A]) {
  return (list.first, Array(list.dropFirst()))
}

func parse(list: [String]) throws -> (Atom, [String]) {
  var tokens = list
  var result: [Atom] = []
  while tokens.first != ")" {
    //#-editable-code Write Code Here
    //#-end-editable-code
  }
  return (.list(result), Array(tokens.dropFirst()))
}

func parse(_ tokens: [String]) throws -> (Atom, [String]) {
  let (first, rest) = head(tokens)
  
  if first == nil {
    throw ParseError.syntaxError("Expected Atom")
  }
  
  switch first! {
  case "(":
    return try parse(list: rest)
    
  case ")":
    throw ParseError.syntaxError("Unexpected ) found.")
    
  default:
    return (Atom(first!), rest)
  }
}

assert(try! parse(["(", "+", "1", "2", ")"]).0 == Atom.list([Atom.symbol("+"), Atom.primative(.int(1)), Atom.primative(.int(2))]))

