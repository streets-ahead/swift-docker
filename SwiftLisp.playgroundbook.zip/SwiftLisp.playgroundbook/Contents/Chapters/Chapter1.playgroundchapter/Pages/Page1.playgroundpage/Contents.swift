//#-hidden-code
import UIKit
import PlaygroundSupport
//#-end-hidden-code
/*:

# Swisp

One note on nomenclature, Lisp is not one language, but a family of languages. There are many dialects of Lisp, just like there are dialects of English. What people in the US might call a flashlight, people in the UK might call a torch. The same applies to Lisps, they all follow the same basic rules but some of the names and conventions are different. Several popular dialects of Lisp include Scheme, Clojure and Common Lisp.

For the purposees of this book I'll call our Lisp dialect Swisp, but the beauty of building your own language is that you're free to name it as you wish.  We'll work on our interpreter in phases.  In this first phase we focus on basic math operations.
 
## Syntax
 
We'll start by going over some of the basics of Swisp's syntax.  If you look over at the live view on the right you can see a prompt, this is what's known as a REPL.  REPL stands for Read-Eval-Print-Loop, and is a common way to use Lisp. You may have seen the Swift REPL on the Mac, this is the same idea. You can enter your program one expression at a time and interact with a shared environment. (*Note:* If you haven't seen the Swift REPL you can access it via the Terminal.  Simply type the command `swift`.)

Here is your first Lisp program:

```
(+ 2 2)
```

 The output of this program is, unsuprisingly, 4.  The prefix notation may look a little strange to you, but what if we had a Swift function defined as below:

```
func add(_ x: Int, _ y: Int) -> Int {
  return x + y
}

add(2, 2) // == 4
```

This is the exact same as the Swisp program, we just shifted the parenthesis, and changed the `+` symbol to the word add.  In Swift `+` is a special operator, that has special behavior, in Swisp there's no such thing, `+` is just a function like any other.  This may seem inconvenient at first, but if you take the time to get used to it, you may come to appricate this consitency and simplicity.
 
 Here are some other sample programs, try entering some of these into the Swisp REPL to the right.

```
(/ 100 5)
(+ 3 4 5 6)
(* 5 (- 5 3))
(+ (* 5 2) (- 10 5))
```

### Lists

In Lisp every set of parenthesis creates a new list. In the case of Swisp these are represented using Swift native Arrays, in many other Lisps they are represented as linked lists.  The first item in the list is a function name or keyword, the rest of the elements represent the function arguments. You can see instead of separating each list element using commas as  we do in Swift, Lisp uses whitespace. By default all lists are evaluated, meaning the first item in the list is executed and passed the rest of the items as arguments.  We can see what this looks like with the following Swift code.

```
func sum(_ numbers: [Int]) -> Int {
  return numbers.reduce(0, +)
}

let expr: [Any] = [sum, 1, 2, 3]
expr[0](expr[1...]) // == 6
```
_**Note:** This Swift code is not actually valid as the types don't match up.  When we implement this functionality in our Swisp interpreter we'll use enums to ensure the types work. The above will run if you add some forced casts, but I left those out for clarity._

### Special Forms

All of the operations we've seen so far are simple functions, but there are a few special forms you'll need to know about.  Special forms look like normal function calls but have special behavior that a normal function could not have.  For example `if` is a special form, that works similarly to `if` in Swift.

```
(if (< x 2) (+ 2 2) 0)
```

In the above example if x less than 2 this expression will return 4 otherwise it will return 0.  So why can't `if` be implemented as a standard function?  The problem is that in a normal function call each argument is evaluated before the function is executed. In the above example that would mean executing `(< x 2)`, `(+ 2 2)`, and `0`, in this case that shouldn't be a problem as long as the correct value is returned, but what if one of the arguments had side effects or takes a long time to compute.  We need to ensure that only the correct child expression is computed.

Aside from `if` there are only two other special forms in this version of Swisp. The first is `def`, which allows you to define a new variable, for example to set x to 42 you'd write `(def x 42)`.  The other is `lambda` which allows you to create a new function. It's signature looks like: `(lambda (arguments...) exp)`.  You'll often want to combine `def` and `lambda` to create new named functions.  

```
(def add5 (lambda (x) (+ x 5)))

(add5 10) -> 15
```

Below is a slightly more complicated example where we use recursion to compute factorial.

```
(def fac (lambda (n) (if (< n 1) 1 (* n (fac (- n 1))))))

(fac 5) -> 720
```

*/

//#-hidden-code
func run() {
  if let proxy = PlaygroundPage.current.liveView as? PlaygroundRemoteLiveViewProxy {
      proxy.send(.string("RUN"))
  }
}
run()
//#-end-hidden-code