import UIKit
import PlaygroundSupport

let repl = TableViewRepl(style: .plain)

class MyLiveView: UIView, PlaygroundLiveViewSafeAreaContainer { }

extension MyLiveView: PlaygroundLiveViewMessageHandler {
  public func liveViewMessageConnectionOpened() { }

  public func liveViewMessageConnectionClosed() { }

  public func receive(_ message: PlaygroundValue) {
    if case let .string(s) = message {
      if s == "RUN" {
        repl.evalCurrent()      
      }
    }
  }
}

let liveView = MyLiveView()
liveView.addSubview(repl.view)
liveView.backgroundColor = .clear

PlaygroundPage.current.liveView = liveView

repl.view.leadingAnchor.constraint(equalTo: liveView.liveViewSafeAreaGuide.leadingAnchor).isActive = true
repl.view.trailingAnchor.constraint(equalTo: liveView.liveViewSafeAreaGuide.trailingAnchor).isActive = true
repl.view.topAnchor.constraint(equalTo: liveView.liveViewSafeAreaGuide.topAnchor).isActive = true
repl.view.bottomAnchor.constraint(equalTo: liveView.liveViewSafeAreaGuide.bottomAnchor).isActive = true
 
